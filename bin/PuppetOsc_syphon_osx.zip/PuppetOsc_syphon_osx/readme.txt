Note: The current version of the Syphon library (beta 2 r7) will only compile with a Processing 2 beta version--not Processing 1.5, not Processing 2.0! The included binary was compiled with Processing 2b8.

Nick Fox-Gieg 19 jun 13